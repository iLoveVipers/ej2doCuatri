function Instrucciones() {

    return (
      <div>
          <h1>Instrucciones</h1>
          <p>
              Lorem, ipsum dolor sit amet consectetur adipisicing elit. Omnis illum iure aliquid rerum quae, error blanditiis cumque quibusdam fuga, perspiciatis dignissimos quam! Cumque quae rerum debitis, repellendus minima commodi necessitatibus?
          </p>
      </div>
    )
  }
  
  export default Instrucciones