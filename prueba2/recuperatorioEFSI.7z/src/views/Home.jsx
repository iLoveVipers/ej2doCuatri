import React from "react";
import Tarea from "../components/Tarea";

export default function Home(){
    return(
        <Tarea></Tarea>
    )
}